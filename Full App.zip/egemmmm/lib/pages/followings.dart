import 'package:egemmmm/services/auth.dart';
import 'package:egemmmm/utils/analytics.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:flutter/material.dart';
import 'package:egemmmm/utils/colors.dart';
import 'package:egemmmm/utils/style.dart';

class followings extends StatefulWidget {

  const followings ({Key key, this.analytics,this.observer}) : super(key: key);

  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  Followings createState() => Followings();
}

class Followings extends State<followings> {

  String _message = "";
  final AuthService _auth = AuthService();
  void setMessage(String msg) {
    setState(() {
      _message = msg;
    });
  }

  @override
  void initState() {
    super.initState();

    setCurrentScreen(widget.analytics, widget.observer, 'Notif Page', 'NotifPageState');

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
          backgroundColor: Appcolors.primary,
          title: Text("FOLLOWING",
              style: appbarText
          ),
          actions: <Widget>[
            TextButton.icon(
              onPressed: () async {
                await _auth.signOut();
              },
              icon: Icon(Icons.person),
              label: Text('Logout'),
            ),]
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://i.stack.imgur.com/34AD2.jpg"),
                ),
                title: Text("Emre Yilmaz"),
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://d.kuzeyekspres.com.tr/news/147564.jpg"),
                ),
                title: Text("Elon Musk "),

          ),
          ),
          ),
            Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://i.pinimg.com/originals/e9/cd/31/e9cd31722ea5ace23ae18cb3d8a549c8.jpg"),
                ),
                title: Text("Tommy boi"),

              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://cdn.yeniakit.com.tr/images/news/625/i-mehmet-3a7e65.jpg"),
                ),
                title: Text("asdgfhdgah mehmet sahgdhsgh"),

              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                  leading: CircleAvatar(
                    radius: 30,
                    backgroundImage: NetworkImage("https://cdn.britannica.com/11/222411-050-D3D66895/American-politician-actor-athlete-Arnold-Schwarzenegger-2016.jpg"),
                  ),
                  title: Text("Arnold Schactschwsczwanagert"),

              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                  leading: CircleAvatar(
                    radius: 30,
                    backgroundImage: NetworkImage("https://static01.nyt.com/images/2020/05/16/business/16JORDAN-01sub/16JORDAN-01sub-superJumbo.jpg"),
                  ),
                  title: Text("Michael Jordan"),

              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://i4.hurimg.com/i/hurriyet/75/0x0/600c9430b699de1ed8fa4871.jpg"),
                ),
                title: Text("Menmetali_erbil"),

              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://cdnuploads.aa.com.tr/uploads/Contents/2017/08/21/thumbs_b_c_e35e718967bf66618a94dda1e55b3235.jpg?v=194337"),
                ),
                title: Text("birb"),

              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://static01.nyt.com/images/2020/05/16/business/16JORDAN-01sub/16JORDAN-01sub-superJumbo.jpg"),
                ),
                title: Text("Michael Jordan fanpage"),

              ),
            ),
          ),


          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://i.pinimg.com/736x/2d/06/d0/2d06d0861bcfb437c8d072b0fc06a648.jpg"),
                ),
                title: Text("Esra baba"),

              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(bottom: 2.0),
            child: Container(
              color: Colors.white,
              child: ListTile(
                leading: CircleAvatar(
                  radius: 30,
                  backgroundImage: NetworkImage("https://i.pinimg.com/originals/64/d5/50/64d550a22af527c499a72c3e1bdc59b8.jpg"),
                ),
                title: Text("stephanie Perez"),

              ),
            ),
          ),
        ],
      ),
    );
  }
}