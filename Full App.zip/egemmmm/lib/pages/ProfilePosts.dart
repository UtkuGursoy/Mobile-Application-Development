import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:egemmmm/services/auth.dart';
import 'package:egemmmm/services/database.dart';
import 'package:egemmmm/utils/analytics.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:egemmmm/objects/user.dart';
import 'package:egemmmm/pages/profilePage.dart';
import 'package:egemmmm/utils/colors.dart';
import 'package:egemmmm/objects/post.dart';
import 'package:egemmmm/posts.dart';
import 'package:egemmmm/utils/style.dart';
import 'package:egemmmm/pages/notifications.dart';
import 'package:provider/provider.dart';

class profilePosts extends StatefulWidget {

  const profilePosts ({Key key, this.analytics,this.observer}) : super(key: key);

  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  ProfilePosts createState() => ProfilePosts();
}

class ProfilePosts extends State<profilePosts> {
final AuthService _auth = AuthService();
@override
  void initState() {
    super.initState();

    setCurrentScreen(widget.analytics, widget.observer, 'Feed Page', 'FeedPageState');

  }
  int postCount = 0;
  String _message = "";
  
  void setMessage(String msg) {
    setState(() {
      _message = msg;
    });
  }
  
  Future<void> _setCurrentScreenFeed() async {
    await widget.analytics.setCurrentScreen(screenName: "feed");
    setMessage("setCurrentScreen succeeded");
  }

  var docRef = FirebaseFirestore.instance
      .collection("users")
      .doc(FirebaseAuth.instance.currentUser.uid);
 

  static User1 kus = User1(
      username:"uzumakinaruto98",
      name: "Naruto",
      follower_num: 12,
      following_num: 123,
      profilePic: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLW_cpXxaMh6K_6dmeW74ZNdbntA9HbToaUfIV3tsmKAfxaSQP6-9Gf7NaUbCwMc6-G-g&usqp=CAU"));


  List<Post> posts = [
    Post(user : kus, location: "Ankara", img: "https://static.wikia.nocookie.net/naruto/images/d/dd/Naruto_Uzumaki%21%21.png/revision/latest?cb=20161013233552://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.webtekno.com%2Fnaruto-online-turkce-dil-secenegiyle-resmi-olarak-turkiye-ye-geliyor-h35046.html&psig=AOvVaw1KlnDerYiZjKB6vGdKvj5u&ust=1623408144025000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMD98-https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.webtekno.com%2Fnaruto-online-turkce-dil-secenegiyle-resmi-olarak-turkiye-ye-geliyor-h35046.html&psig=AOvVaw1KlnDerYiZjKB6vGdKvj5u&ust=1623408144025000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMD98-73jPECFQAAAAAdAAAAABAh://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.asialogy.com%2Fnaruto-anime-tanitim%2F&psig=AOvVaw1KlnDerYiZjKB6vGdKvj5u&ust=1623408144025000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMD98-73jPECFQAAAAAdAAAAABAb" ,text: 'Hello World', date: '19 March 2021', likes: 30, commentNum: 10),
    Post(user : kus, location: "Istanbul", img: "https://i.pinimg.com/originals/1a/15/2a/1a152a95db5600555157de952337411d.png",text: 'Hello World 2', date: '18 March 2021', likes: 20, commentNum: 22),
    Post(user : kus, location: "Izmir", img: "https://occ-0-1068-1723.1.nflxso.net/dnm/api/v6/9pS1daC2n6UGc3dUogvWIPMR_OU/AAAABZtkFKv3vCiFAktNKBHox0qJnc95GnLtRDyDppk3cFzpooxSORT0EWTHwE5rCbHy-6cb8F4isoLDFWlcnlIbGS_rks0Tnt0bSqdU7iCzxJqGfC56.jpg?r=0d2" ,text: 'Hello World 3', date: '17 March 2021', likes: 10, commentNum: 30),
    Post(user : kus, location: "Ankara", img: "https://e7.pngegg.com/pngimages/635/901/png-clipart-naruto-shippuden-ultimate-ninja-storm-2-naruto-shippuden-ultimate-ninja-storm-4-naruto-ultimate-ninja-storm-naruto-uzumaki-sasuke-uchiha-naruto-s-orange-chibi-thumbnail.png",text: 'Hello World 2', date: '18 March 2021', likes: 20, commentNum: 22),
    Post(user : kus, location: "Istanbul", img: "https://i.pinimg.com/originals/1a/15/2a/1a152a95db5600555157de952337411d.png",text: 'Hello World 2', date: '18 March 2021', likes: 20, commentNum: 22),
    Post(user : kus, location: "Izmir", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYTVhlVLXaye83Jhok-qCMPNccaLw_8rernA&usqp=CAU" ,text: 'Hello World 3', date: '17 March 2021', likes: 10, commentNum: 30),

  ];

  void buttonPressed() {
    setState(() {
      postCount += 1;
    });
  }

  void profilePage() {
    setState(() {
      Navigator.pushNamed(context, '/profile');

    });
  }

  @override
  Widget build(BuildContext context) {

    return StreamProvider<QuerySnapshot>.value(
      value: DatabaseService().users,
      initialData: null,
          child: Scaffold(
        backgroundColor: Appcolors.bg,

        appBar: AppBar(
          backgroundColor: Appcolors.primary,
          title: Text(
              "Naruto's Posts",
              style: appbarText
          ),
          actions: <Widget>[
            TextButton.icon(
                onPressed: () async {
                  await _auth.signOut();
                },
                icon: Icon(Icons.person),
                label: Text('Logout'),
            ),// appBardaki notifications iconu eklendi
            IconButton(
              iconSize: 40,
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => notifications()
                )
                );
              },
              icon: Icon(Icons.notifications),
            ),
          ],
        ),

        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[


            Column(
              children: posts.map((post) => PostCard(
                  post: post,
                  delete: () {
                    setState(() {
                      posts.remove(post);
                    });
                  }
            )).toList(),
          ),

            SizedBox(),
          ],
        ),
      ),
      ),
    );
  }
}
